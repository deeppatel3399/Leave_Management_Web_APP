// import React from 'react';

// const FormInputBox = (props) => {
//   return (
//     <>
//         <input className={props.className} 
//         name={props.name}
//          id={props.id} 
//         //  value={email} onChange={(e)=>{setEmail(e.target.value)}} 
//         //  onBlur={emailblur} 
//          type={props.type}
//          placeholder={props.placeholder}/>
//         {/* <span className='reginputerr'>{emailErr}</span> */}
//     </>
//   )
// }

// export default FormInputBox;