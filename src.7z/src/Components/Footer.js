import React from 'react';

const Footer = () => {
  return (
    <>
      <div className='bg-primary-dark'> 
                Footer Section
      </div>
    </>
  );
};

export default Footer;