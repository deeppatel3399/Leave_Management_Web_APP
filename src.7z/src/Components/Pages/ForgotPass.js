import React from 'react';

const ForgotPass = () => {
  return (
    <>
    </>
  );
};

export default ForgotPass;