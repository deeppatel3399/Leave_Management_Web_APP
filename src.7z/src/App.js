import React from 'react';
import Home from './Components/Pages/Home';

const App = () => {
  return (
    <>
     <Home/>
    </>
  );
};

export default App;